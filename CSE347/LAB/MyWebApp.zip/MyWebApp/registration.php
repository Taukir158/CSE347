<html>
   <title> Registration </title>
           <body>
		   <form action="insertdata.php" method="POST">
                 <table> 
				     <tr>
					  
					     <td><label for="name">Name  </label></td>
						 <td><input type="text" name="name"></td>
					</tr>
					<tr>
						 <td><label for="PhnNo">Phone no </label></td>
						 <td><input type="text" name="phnNo"></td>
					</tr>
					<tr>
						 <td></td>
						 <td><input type="submit" name="submit" value="Register"></td>
					  
					  </tr>
				 
				 
				 
				 
				 
				 </table>
				 </form>
  
            </body>





</html>